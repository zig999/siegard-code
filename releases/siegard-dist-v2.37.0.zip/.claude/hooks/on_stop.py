#!/usr/bin/env python3
"""
Stop hook: aggregates session metrics and writes .orch/metrics/current.json.

Triggered by Claude Code on session end (settings.json Stop hook).
Reads the current OrchState via reduce_all() and writes a structured metrics
file. Never raises — all exceptions are swallowed so the hook never blocks shutdown.

Output: .orch/metrics/current.json
"""
import json
import os
import sys
from pathlib import Path

_LIB = Path(__file__).resolve().parents[1] / "lib"
sys.path.insert(0, str(_LIB))

from orch_core import (
    reduce_all, TaskStatus, PhaseStatus, ORCH_DIR, METRICS_DIR,
    ensure_dirs, now_iso, parse_iso, read_events_filtered,
    cleanup_stale_workers, reap_stale_tasks, detect_stale_orchestrator,
    compute_progress,
)


def _workflow_is_terminal(state) -> bool:
    """True iff every REQUIRED declared phase is COMPLETED — the same rule M3 uses
    to derive run_status == "completed" (orch_core._m3_derive_run_status), re-derived
    here directly from state.phases.

    Deliberately NOT the same as _compute_metrics()'s own `run_status` field below:
    that field is a TASK-COUNT heuristic ("completed == total_tasks so far"), which
    can read "completed" mid-workflow — e.g. dev phase's tasks are all terminal but
    review's tasks haven't been created yet. Gating the quiescence guard on that
    heuristic would silence exactly the "all tasks terminal, exit never emitted"
    driverless state this project's own 2026-07-15 workflow audit flagged as
    dangerous to mask (scenario 2c) — the opposite of what this guard should do.
    """
    if not state.phases:
        return False
    required = [p for p in state.phases.values() if p.required]
    # Non-empty guard mirrors M3 exactly (2026-07-15 post-fix audit, gap 6a): with
    # every phase declared required:false, all(<empty>) is vacuously True while M3
    # still derives "active" — the reap/cleanup backstop would go silent for a
    # workflow the engine considers live.
    if not required:
        return False
    return all(p.status == PhaseStatus.COMPLETED for p in required)


def _detect_orphaned_phase(state) -> dict | None:
    """
    Returns a diagnostic dict when a phase_entered event exists with no tasks
    dispatched and no escalation — the phase orchestrator was never spawned.
    This happens when the meta-orchestrator is interrupted between Step 5
    (phase_entered) and Step 6 (Agent spawn).
    """
    if state.current_phase is None:
        return None
    phase = state.phases.get(state.current_phase)
    if phase is None or phase.status.value != "active":
        return None
    if state.escalation is not None:
        return None
    # If the workflow has no tasks at all it is "empty", not orphaned.
    if not state.tasks:
        return None
    phase_tasks = [t for t in state.tasks.values() if t.phase == state.current_phase]
    if phase_tasks:
        return None
    return {
        "orphaned_phase": state.current_phase,
        "entered_at": phase.entered_at,
        "action_required": "re-invoke orchestrator — phase_entered emitted but phase orchestrator was never dispatched",
    }


def _detect_stuck_improve_spec(state, orch_dir: Path) -> dict | None:
    """
    Returns a diagnostic dict when an improve workflow has completed SDD tasks but
    spec_change_status was never closed (no spec_pipeline_return event emitted).
    Indicates orchestrator-sdd ran without the spec_pipeline_return fix deployed.
    """
    sessions_dir = orch_dir / "sessions"
    if not sessions_dir.exists():
        return None
    import json as _json
    for scope_path in sessions_dir.glob("*/improve-scope.json"):
        try:
            scope = _json.loads(scope_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if scope.get("spec_change_status") != "pending_spec":
            continue
        workflow_id = scope.get("workflow_id", scope_path.parent.name)
        sdd_completed = [
            t for t in state.tasks.values()
            if t.phase == "sdd" and t.status.value == "completed"
        ]
        if not sdd_completed:
            continue
        returns = read_events_filtered(event_type="spec_pipeline_return")
        if any(e.data.get("workflow_id") == workflow_id for e in returns):
            continue
        return {
            "stuck_improve_spec": str(scope_path.relative_to(orch_dir.parent)),
            "workflow_id": workflow_id,
            "sdd_tasks_completed": len(sdd_completed),
            "action_required": (
                f"SDD phase completed but spec_change_status was never closed "
                f"(spec_pipeline_return not emitted). "
                f"Deploy latest orchestrator-sdd.md+orch_core.py and re-invoke /u-orchestrator, "
                f"OR run: python3 .claude/scripts/fix_stuck_improve.py "
                f"--session {workflow_id} --action accept_divergence"
            ),
        }
    return None


def _detect_unfinalized_sdd_phase(state, events: list) -> dict | None:
    """
    Returns a diagnostic when the SDD phase ran its pipeline to a clean terminal
    but was never formally finalized (F-05).

    Symptom from the field: the log ends with the validator's task_completed
    (handoff_allowed: true), but there is no phase_transitioned out of sdd — the
    orchestrator was cut off after the last worker's terminal, before it could
    regenerate handoff-manifest.yaml + emit phase_exit_approved/phase_transitioned.
    An observer reading only task_completed concludes "done"; in reality the handoff
    was never published and a downstream /u-dev would consume a stale manifest.

    Conditions (all must hold to avoid false positives):
      - sdd phase is still active (current_phase == "sdd" — never transitioned)
      - no escalation pending and no DLQ task (those are surfaced by other paths)
      - sdd has tasks and ALL of them are completed (no running/scheduled/failed)
      - no phase_transitioned event left the sdd phase

    Note: spec_pipeline_return is NOT required here — it is emitted only for the
    /u-improve trigger. The definitive sdd terminal is phase_transitioned.
    """
    if state.current_phase != "sdd":
        return None
    if state.escalation is not None:
        return None

    sdd_tasks = [t for t in state.tasks.values() if t.phase == "sdd"]
    if not sdd_tasks:
        return None  # empty or orphaned — handled by _detect_orphaned_phase
    if any(t.status.value == "dlq" for t in sdd_tasks):
        return None  # DLQ blocks exit — surfaced as an error elsewhere
    if not all(t.status.value == "completed" for t in sdd_tasks):
        return None  # pipeline still has live/failed work — not finalization-pending

    transitions = [
        e for e in events
        if e.event_type == "phase_transitioned" and e.data.get("from_phase") == "sdd"
    ]
    if transitions:
        return None  # already finalized

    return {
        "unfinalized_phase": "sdd",
        "sdd_tasks_completed": len(sdd_tasks),
        "action_required": (
            "SDD workers all completed but the phase was never finalized "
            "(no phase_transitioned from sdd; handoff-manifest.yaml not regenerated). "
            "Re-invoke the orchestrator — orchestrator-sdd re-runs the exit-criteria gate, "
            "regenerates the handoff manifest, and emits phase_exit_approved/phase_transitioned. "
            "Until then the SDD handoff is NOT published; do not start /u-dev."
        ),
        "command": "/u-orchestrator",
    }


def _write_unfinalized_sdd_alert(unfinalized: dict, metrics: dict) -> None:
    """Writes .orch/last_error.json with an unfinalized-SDD-phase diagnostic."""
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": "sdd_finalization_pending",
        "last_seq": metrics.get("last_seq"),
        "diagnostic": unfinalized,
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_stuck_improve_alert(stuck: dict, metrics: dict) -> None:
    """Writes .orch/last_error.json with a stuck-improve-spec diagnostic."""
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": "stuck_improve_spec",
        "last_seq": metrics.get("last_seq"),
        "diagnostic": stuck,
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _count_escalations(events: list | None) -> tuple[int, dict[str, int]]:
    """Count escalation EVENTS from the log (SGD-004).

    The metric used to be ``1 if state.escalation else 0`` — a boolean over the
    *currently pending* escalation. On a completed run every escalation was
    already resolved by a human_response, so state.escalation is None and the
    metric read 0 even when several escalations occurred. Governance/SLA reports
    need the real count, derived from the log (P1/P2 — the log is the truth).
    """
    if events is None:
        events = list(read_events_filtered(event_type=None))
    total = 0
    by_code: dict[str, int] = {}
    for e in events:
        if e.event_type != "escalation":
            continue
        total += 1
        data = e.data if isinstance(e.data, dict) else {}
        code = data.get("code")
        if code:
            by_code[code] = by_code.get(code, 0) + 1
    return total, by_code


# R11c — spec:code ratio.
#
# Measured by hand once: 1.096 lines of spec for 419 lines of code (2.6:1) on a
# change that introduced no behaviour by construction. That diagnosis only exists
# because someone counted; nothing in the engine recorded it. A single anecdote
# also cannot answer the question it raises — whether the artifact model itself is
# worth its cost — so the number has to accumulate per workflow.
#
# Counted from the git index, not from the log: the log knows which tasks ran, not
# how many lines they wrote. Best-effort by design — a project without git, or a
# run with no commits yet, yields nulls rather than blocking session close.
_SPEC_PATH_MARKERS = ("/specs/", "specs/", "/spec/")
_CODE_EXTENSIONS = (
    ".ts", ".tsx", ".js", ".jsx", ".py", ".go", ".rs", ".java", ".kt", ".cs",
    ".rb", ".php", ".swift", ".sql", ".vue", ".svelte",
)


def _is_spec_path(path: str) -> bool:
    p = path.replace("\\", "/")
    if any(m in p for m in _SPEC_PATH_MARKERS):
        return True
    return p.endswith((".spec.md", ".back.md", "openapi.yaml"))


def _spec_code_ratio() -> dict:
    """Lines of spec vs lines of code added since the workflow's first commit.

    Uses `git log --numstat` over the commits made while the workflow ran, which
    is the closest deterministic proxy available: commit boundaries are the only
    durable record of what the phases produced.
    """
    import subprocess

    empty = {
        "spec_lines_added": None, "code_lines_added": None, "ratio": None,
        "commits_counted": 0, "basis": "unavailable",
    }
    project_dir = ORCH_DIR.parent
    try:
        # Commits since the log's first event — the workflow's own window.
        proc = subprocess.run(
            # `%x00` is a literal NUL: a commit marker that cannot collide with a
            # path. A bare word here is not a valid --pretty format and git exits
            # with "fatal: invalid --pretty format".
            ["git", "-C", str(project_dir), "log", "--numstat",
             "--format=%x00", "--no-merges", "-n", "50"],
            capture_output=True, text=True, timeout=30,
        )
    except (OSError, subprocess.SubprocessError):
        return empty
    if proc.returncode != 0:
        return {**empty, "basis": "not a git repository"}

    spec_lines = code_lines = commits = 0
    for line in proc.stdout.splitlines():
        if line.startswith("\x00"):
            commits += 1
            continue
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        added_raw, _removed, path = parts
        if added_raw == "-":  # binary
            continue
        try:
            added = int(added_raw)
        except ValueError:
            continue
        if _is_spec_path(path):
            spec_lines += added
        elif path.endswith(_CODE_EXTENSIONS):
            code_lines += added

    if spec_lines == 0 and code_lines == 0:
        return {**empty, "commits_counted": commits, "basis": "no counted changes"}

    ratio = round(spec_lines / code_lines, 2) if code_lines else None
    return {
        "spec_lines_added": spec_lines,
        "code_lines_added": code_lines,
        "ratio": ratio,
        "commits_counted": commits,
        "basis": "git log --numstat over the last 50 non-merge commits",
    }


def _last_cost_projection(events: list | None) -> dict | None:
    """The most recent `cost_projected` payload, so projection and outcome sit
    side by side in one file — otherwise the estimate can never be calibrated."""
    if events is None:
        events = list(read_events_filtered(event_type=None))
    for e in reversed(events):
        if e.event_type == "cost_projected":
            return e.data if isinstance(e.data, dict) else None
    return None


def _compute_metrics(state=None, events=None) -> dict:
    if state is None:
        state = reduce_all()
    escalations_total, escalations_by_code = _count_escalations(events)

    tasks_by_status: dict[str, int] = {}
    for t in state.tasks.values():
        key = t.status.value if hasattr(t.status, "value") else str(t.status)
        tasks_by_status[key] = tasks_by_status.get(key, 0) + 1

    phases_completed = sum(
        1 for p in state.phases.values()
        if p.status == PhaseStatus.COMPLETED
    )

    phase_durations: dict[str, float | None] = {}
    for name, p in state.phases.items():
        if p.entered_at and p.completed_at:
            entered = parse_iso(p.entered_at)
            completed = parse_iso(p.completed_at)
            phase_durations[name] = (completed - entered).total_seconds()
        else:
            phase_durations[name] = None

    total_tasks = len(state.tasks)
    completed = tasks_by_status.get("completed", 0)
    failed = tasks_by_status.get("failed", 0)
    dlq = tasks_by_status.get("dlq", 0)

    if total_tasks == 0:
        run_status = "empty"
    elif state.escalation:
        run_status = "escalated"
    elif dlq > 0 and (completed + dlq) == total_tasks:
        run_status = "completed_with_dlq"
    elif completed == total_tasks:
        run_status = "completed"
    else:
        run_status = "partial"

    # SIEGARD-01: failure observability. Count terminal failures by reason so
    # structural worker deaths (worker_exited_without_terminal / stale_timeout)
    # are visible in metrics instead of hiding inside tasks_failed. Compared by
    # status string to stay reload-safe (see _compute_metrics enum usage above).
    failure_reason_breakdown: dict[str, int] = {}
    for t in state.tasks.values():
        status = t.status.value if hasattr(t.status, "value") else str(t.status)
        if status in ("failed", "dlq"):
            reason = getattr(t, "last_failure_reason", None)
            if reason:
                failure_reason_breakdown[reason] = failure_reason_breakdown.get(reason, 0) + 1
    structural_failures = sum(
        n for r, n in failure_reason_breakdown.items() if r in _WORKER_STOPPED_REASONS
    )
    structural_failure_rate = (structural_failures / total_tasks) if total_tasks else 0.0

    return {
        "generated_at": now_iso(),
        "workflow_id": state.workflow_id,
        "run_status": run_status,
        "current_phase": state.current_phase,
        "last_seq": state.last_seq,
        "tasks_total": total_tasks,
        "tasks_by_status": tasks_by_status,
        "tasks_completed": completed,
        "tasks_failed": failed,
        "tasks_dlq": dlq,
        "phases_completed": phases_completed,
        "phase_durations": phase_durations,
        "escalations": escalations_total,
        "escalations_pending": 1 if state.escalation else 0,
        "escalations_by_code": escalations_by_code,
        "circuit_breaker_tripped": state.circuit_breaker is not None,
        "failure_reason_breakdown": failure_reason_breakdown,
        "structural_failure_rate": structural_failure_rate,
        # R11c: spec:code ratio. Without it the disproportion is invisible — the
        # diagnosis that found a 2.6:1 spec-to-code ratio on a change that
        # introduced no behaviour only exists because someone counted lines by
        # hand. It is also the prerequisite for deciding anything about the
        # artifact model (is a separate *.back.md worth its cost?): that call
        # needs a trend, not one anecdote.
        "spec_code_ratio": _spec_code_ratio(),
        "cost_projection": _last_cost_projection(events),
        "progress": compute_progress(state),
    }


def _detect_stale_orchestrator(state, events: list) -> dict | None:
    """
    Returns a diagnostic when a phase is active and has non-terminal tasks but no
    ORCHESTRATOR_HEARTBEAT was emitted within the stale threshold.

    Indicates the orchestrator LLM was alive (no crash) but stopped making
    progress — typically caused by emitting narrative text instead of events.

    Delegates to orch_core.detect_stale_orchestrator (the single, unit-tested
    source of truth, also called by the live orchestrator's Step 5.0 check).
    """
    return detect_stale_orchestrator(state, events, now_iso())


_ORPHANED_RETRY_CODE = "E27_retry_scheduled_without_actuator"


def _escalate_orphaned_retry(reaped: list, state) -> None:
    """Record, in the log, that a retry was scheduled with nothing left to run it.

    Emitted at most once per workflow: repeating it on every session close would
    bury the signal it exists to raise.
    """
    from orch_core import EventType, append_event, read_events

    for event in read_events():
        if (event.event_type == EventType.ESCALATION.value
                and (event.data or {}).get("code") == _ORPHANED_RETRY_CODE):
            return

    append_event(
        agent="stale-monitor",
        event_type=EventType.ESCALATION.value,
        data={
            "code": _ORPHANED_RETRY_CODE,
            "severity": "warning",
            "reason": (
                f"session ended after reaping {len(reaped)} stale task(s) and "
                "scheduling their retries. A scheduled retry is promoted only by a "
                "phase orchestrator's dispatch loop, and none is running — the "
                "retries will not fire on their own."
            ),
            "evidence": [state.last_seq],
            "reaped_tasks": list(reaped)[:20],
            "suggested_actions": [
                "the SessionStart hook (recovery_tick.py) promotes these on the next session",
                "or re-invoke the meta-orchestrator now to resume the phase",
                "to avoid the wait entirely, run supervision: /loop 5m /u-supervise <workflow_id>",
            ],
        },
    )


def _write_stale_orchestrator_alert(stale: dict, metrics: dict) -> None:
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": "stale_orchestrator",
        "last_seq": metrics.get("last_seq"),
        "diagnostic": stale,
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


# Failure reasons that mean "the worker stopped without emitting a terminal" — the
# synthesized/reaped death paths the recovery diagnostic surfaces. on_subagent_stop
# emits worker_exited_without_terminal; the deterministic reaper emits stale_timeout
# (the primary death path after F-03 made the hook defer ambiguous multi-worker stops).
_WORKER_STOPPED_REASONS = frozenset({
    "worker_exited_without_terminal",
    "stale_timeout",
})


def _detect_worker_stopped_failures(state) -> dict | None:
    """
    Returns a structured recovery diagnostic when the session ended with tasks
    failed because their worker stopped without emitting a terminal event —
    synthesized by on_subagent_stop (worker_exited_without_terminal) or by the
    stale reaper (stale_timeout).

    These failures are retryable but require the orchestrator to be re-invoked.
    This function surfaces the actionable recovery steps so operators don't
    need to inspect the raw log to understand what happened.
    """
    stopped_tasks = [
        t for t in state.tasks.values()
        if t.status in (TaskStatus.FAILED, TaskStatus.SCHEDULED)
        and getattr(t, "last_failure_reason", None) in _WORKER_STOPPED_REASONS
    ]
    if not stopped_tasks:
        return None

    return {
        "worker_stopped_count": len(stopped_tasks),
        "affected_tasks": [
            {
                "task_id": t.task_id,
                "phase": t.phase,
                "status": t.status.value if hasattr(t.status, "value") else str(t.status),
                "attempts": t.attempts,
            }
            for t in stopped_tasks
        ],
        "action_required": (
            "Re-invoke the orchestrator — these tasks were synthesized as failed by "
            "on_subagent_stop because their workers stopped without emitting a terminal event. "
            "They are retryable and will be picked up automatically on next orchestrator run."
        ),
        "command": "/u-orchestrator",
    }


_ERROR_RUN_STATUSES = frozenset({"escalated", "partial", "completed_with_dlq"})
_ERROR_EVENT_TYPES = frozenset({
    "task_failed", "task_dlq", "escalation", "circuit_breaker_tripped", "preflight_failed",
})


def _write_last_error(metrics: dict, events: list | None = None) -> None:
    """Writes .orch/last_error.json with the last error-related event from the log."""
    if events is None:
        events = list(read_events_filtered(event_type=None))
    error_events = [e for e in events if e.event_type in _ERROR_EVENT_TYPES]
    if not error_events:
        return
    last = error_events[-1]
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": metrics.get("run_status"),
        "last_seq": metrics.get("last_seq"),
        "last_error_event": last.to_dict(),
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_orphan_alert(orphan: dict, metrics: dict) -> None:
    """Writes .orch/last_error.json with an orphaned-phase diagnostic."""
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": "orphaned_phase",
        "last_seq": metrics.get("last_seq"),
        "diagnostic": orphan,
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _write_worker_stopped_alert(stopped: dict, metrics: dict) -> None:
    """Writes .orch/last_error.json with a worker_stopped recovery diagnostic."""
    payload = {
        "generated_at": now_iso(),
        "workflow_id": metrics.get("workflow_id"),
        "run_status": "worker_stopped_recovery_required",
        "last_seq": metrics.get("last_seq"),
        "diagnostic": stopped,
    }
    out_path = ORCH_DIR / "last_error.json"
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    try:
        log_file = ORCH_DIR / "log.jsonl"
        if not log_file.exists():
            return

        ensure_dirs()

        # Quiescence guard (recommendation #6, 2026-07-15 workflow audit): once a
        # workflow is genuinely terminal (every required phase COMPLETED — nothing
        # wall-clock-driven, like reaping or worker-registry cleanup, can ever newly
        # apply to it), skip the whole pipeline if the log hasn't grown since the
        # last time metrics were computed. Without this, a finished workflow whose
        # .orch/ was never purged pays 3 reduce_all() calls, a full unconditional
        # log parse, and 5 detectors on EVERY turn, forever, in every session of the
        # project — the guard here was previously just "does log.jsonl exist".
        # Runs at least once right after completion (last_seq differs from the
        # cached snapshot then), so final cleanup/detection still happens exactly
        # once; only genuinely idle subsequent turns are skipped.
        probe_state = reduce_all()
        if _workflow_is_terminal(probe_state):
            cached_path = METRICS_DIR / "current.json"
            if cached_path.exists():
                try:
                    cached = json.loads(cached_path.read_text(encoding="utf-8"))
                    if cached.get("last_seq") == probe_state.last_seq:
                        return
                except Exception:
                    pass

        # Purge stale worker registry entries from interrupted sessions before
        # computing state — prevents phantom worker_stopped detections on next run.
        try:
            cleanup_stale_workers(max_age_seconds=3600)
        except Exception:
            pass

        # prod-hardening task 06 (A2-F1): reap hung RUNNING tasks deterministically
        # at session end — backstop to the orchestrator Step 5.0 check_stale.py call.
        try:
            reaped = reap_stale_tasks()
        except Exception:
            reaped = []

        events = list(read_events_filtered(event_type=None))
        state = reduce_all()

        # R07c: a retry scheduled HERE has no actuator. `reap_stale_tasks` schedules
        # the retry atomically with the failure (F3/F4), but the only components that
        # promote a scheduled retry are the phase orchestrators' dispatch loops — and
        # this hook runs as the session ends, so the orchestrator is already gone.
        # Observed: task_failed + task_scheduled_retry at 23:19:36, next_retry_at
        # 23:20:02, and the log ends there. Say so in the LOG, not only in a passive
        # last_error.json that nobody was reading.
        #
        # recovery_tick.py (SessionStart) is the actuator that resolves it; this
        # escalation is what tells a reader the workflow is waiting for one.
        if reaped:
            try:
                _escalate_orphaned_retry(reaped, state)
            except Exception:
                pass
        metrics = _compute_metrics(state, events)
        metrics["orphaned_phase"] = None

        orphan = _detect_orphaned_phase(state)
        if orphan:
            metrics["orphaned_phase"] = orphan["orphaned_phase"]
            metrics["run_status"] = "orphaned_phase"
            _write_orphan_alert(orphan, metrics)

        metrics["stuck_improve_spec"] = None
        stuck = _detect_stuck_improve_spec(state, ORCH_DIR)
        if stuck:
            metrics["stuck_improve_spec"] = stuck["workflow_id"]
            if metrics.get("run_status") not in ("orphaned_phase",):
                metrics["run_status"] = "stuck_improve_spec"
            _write_stuck_improve_alert(stuck, metrics)

        metrics["sdd_finalization_pending"] = None
        unfinalized = _detect_unfinalized_sdd_phase(state, events)
        if unfinalized:
            metrics["sdd_finalization_pending"] = unfinalized["unfinalized_phase"]
            if metrics.get("run_status") not in ("orphaned_phase", "stuck_improve_spec"):
                metrics["run_status"] = "sdd_finalization_pending"
            _write_unfinalized_sdd_alert(unfinalized, metrics)

        metrics["stale_orchestrator"] = None
        stale = _detect_stale_orchestrator(state, events)
        if stale:
            metrics["stale_orchestrator"] = stale["stale_orchestrator"]
            if metrics.get("run_status") not in ("orphaned_phase", "stuck_improve_spec", "sdd_finalization_pending"):
                metrics["run_status"] = "stale_orchestrator"
            _write_stale_orchestrator_alert(stale, metrics)

        # Detect tasks that failed via on_subagent_stop synthesis and need
        # orchestrator re-invocation to retry. Surfaces recovery instructions
        # in last_error.json so operators don't need to read the raw log.
        metrics["worker_stopped_recovery"] = None
        stopped = _detect_worker_stopped_failures(state)
        if stopped:
            metrics["worker_stopped_recovery"] = stopped["worker_stopped_count"]
            if metrics.get("run_status") not in ("orphaned_phase", "stuck_improve_spec", "sdd_finalization_pending"):
                metrics["run_status"] = "worker_stopped_recovery_required"
            _write_worker_stopped_alert(stopped, metrics)

        out_path = METRICS_DIR / "current.json"
        out_path.write_text(json.dumps(metrics, indent=2) + "\n", encoding="utf-8")

        if (
            metrics.get("run_status") in _ERROR_RUN_STATUSES
            or metrics.get("circuit_breaker_tripped")
            or metrics.get("escalations_pending", 0) > 0
        ):
            _write_last_error(metrics, events)
    except Exception:
        pass  # Hook must never block shutdown


if __name__ == "__main__":
    main()
